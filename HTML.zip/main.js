console.log('Hello World!');

body {background-color: rgb(201, 76, 76);}